import pygame
import random
import math
import time
from pygame import mixer

BACKGROUND_COLOR = (0, 0, 255)
WALLS_COLOR = (0, 0, 0)
PLAYER_COLOR = (255, 255, 2)
MONSTER_COLOR = (130, 89, 33)
POINT_COLOR = (255, 0, 0)
BLOCK_SIZE = 51
PLAYER_MOVE = 25
POINT_RADIUS = 10
MOUTH_WIDTH = 0
MOUTH = 12.5

count = 0
count_2 = 185
count_3 = 0

pygame.init()

screen = pygame.display.set_mode([1000, 1000])

m = [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], 
     [1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1],
     [1, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 1],
     [1, 2, 1, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 1],
     [1, 2, 1, 2, 1, 1, 1, 2, 2, 2, 1, 1, 1, 2, 1, 2, 1, 2, 1, 1],
     [1, 2, 1, 2, 1, 2, 2, 2, 1, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 1],
     [1, 2, 1, 2, 1, 2, 2, 2, 1, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 1],
     [1, 2, 1, 2, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 1],
     [1, 2, 1, 2, 2, 2, 2, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 1],
     [1, 2, 1, 1, 1, 1, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 1],
     [1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 1, 2, 1, 1, 2, 1, 2, 1, 1],
     [1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 2, 1, 2, 1, 2, 1, 1],
     [1, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 1],
     [1, 2, 1, 2, 1, 1, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 1, 2, 2, 1],
     [1, 2, 1, 2, 1, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1],
     [1, 2, 1, 2, 1, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1],
     [1, 2, 1, 2, 1, 1, 1, 2, 1, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 1],
     [1, 2, 1, 2, 2, 2, 2, 2, 1, 1, 2, 1, 2, 1, 1, 1, 1, 2, 2, 1],
     [1, 2, 2, 2, 1, 1, 1, 2, 1, 1, 2, 1, 2, 2, 2, 2, 2, 2, 1, 1],              
     [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]]

#field's functions
def draw_rect(x, y):
    pygame.draw.rect(screen, WALLS_COLOR, pygame.Rect(x, y, BLOCK_SIZE, BLOCK_SIZE))

def draw_rect_2(x, y):
    pygame.draw.rect(screen, BACKGROUND_COLOR, pygame.Rect(x, y, BLOCK_SIZE, BLOCK_SIZE))    

def draw_point(x, y):
    pygame.draw.circle(screen, (POINT_COLOR), (x, y), POINT_RADIUS)

#player's functions
def draw_player(x, y):
    pygame.draw.circle(screen, (PLAYER_COLOR), (x, y), PLAYER_MOVE)

def draw_eye(x, y):
    pygame.draw.circle(screen, (WALLS_COLOR), (x + 7, y - 15), 5)

def draw_player_1(x, y):
    pygame.draw.circle(screen, (PLAYER_COLOR), (x, y), PLAYER_MOVE)
    pygame.draw.polygon(screen, (BACKGROUND_COLOR), [(x, y), (x + PLAYER_MOVE, y - MOUTH), (x + PLAYER_MOVE, y + MOUTH)], MOUTH_WIDTH)
     
def draw_player_2(x, y):
    pygame.draw.circle(screen, (PLAYER_COLOR), (x, y), PLAYER_MOVE)
    pygame.draw.polygon(screen, (BACKGROUND_COLOR), [(x, y), (x + PLAYER_MOVE, y - PLAYER_MOVE), (x + PLAYER_MOVE, y + PLAYER_MOVE)], MOUTH_WIDTH)

def draw_mouth_1(x, y):
    pygame.draw.circle(screen, (PLAYER_COLOR), (x, y), PLAYER_MOVE)
    pygame.draw.polygon(screen, (BACKGROUND_COLOR), [(x, y), (x - PLAYER_MOVE, y - MOUTH), (x - PLAYER_MOVE, y + MOUTH)], MOUTH_WIDTH)

def draw_mouth_2(x, y):
    pygame.draw.circle(screen, (PLAYER_COLOR), (x, y), PLAYER_MOVE)
    pygame.draw.polygon(screen, (BACKGROUND_COLOR), [(x, y), (x - PLAYER_MOVE, y - PLAYER_MOVE), (x - PLAYER_MOVE, y + PLAYER_MOVE)], MOUTH_WIDTH)

def draw_mouth_3(x, y):
    pygame.draw.circle(screen, (PLAYER_COLOR), (x, y), PLAYER_MOVE)
    pygame.draw.polygon(screen, (BACKGROUND_COLOR), [(x, y), (x - MOUTH, y - PLAYER_MOVE), (x + MOUTH, y - PLAYER_MOVE)], MOUTH_WIDTH)

def draw_mouth_4(x, y):
    pygame.draw.circle(screen, (PLAYER_COLOR), (x, y), PLAYER_MOVE)
    pygame.draw.polygon(screen, (BACKGROUND_COLOR), [(x, y), (x - PLAYER_MOVE, y - PLAYER_MOVE), (x + PLAYER_MOVE, y - PLAYER_MOVE)], MOUTH_WIDTH)            

def draw_mouth_5(x, y):
    pygame.draw.circle(screen, (PLAYER_COLOR), (x, y), PLAYER_MOVE)
    pygame.draw.polygon(screen, (BACKGROUND_COLOR), [(x, y), (x - MOUTH, y + PLAYER_MOVE), (x + MOUTH, y + PLAYER_MOVE)], MOUTH_WIDTH)

def draw_mouth_6(x, y):
    pygame.draw.circle(screen, (PLAYER_COLOR), (x, y), PLAYER_MOVE)
    pygame.draw.polygon(screen, (BACKGROUND_COLOR), [(x, y), (x - PLAYER_MOVE, y + PLAYER_MOVE), (x + PLAYER_MOVE, y + PLAYER_MOVE)], MOUTH_WIDTH)

#monsters functions                       
def draw_monster(monster):
    pygame.draw.circle(screen, (MONSTER_COLOR), (monster.x, monster.y), PLAYER_MOVE)

#move functions
def move_check(x, y):
    x //= BLOCK_SIZE
    y //= BLOCK_SIZE
    return m[y][x]

def move_check_full(x, y):
    if move_check(x - PLAYER_MOVE, y - PLAYER_MOVE) != 1 and\
       move_check(x + PLAYER_MOVE, y + PLAYER_MOVE) != 1 and\
       move_check(x + PLAYER_MOVE, y - PLAYER_MOVE) != 1 and\
       move_check(x - PLAYER_MOVE, y + PLAYER_MOVE) != 1:
        return True 
    return False

def draw_field():
    for cnt in range(len(m)):
        for n in range(len(m[cnt])):
            if m[cnt][n] == 1:
                draw_rect(0 + BLOCK_SIZE*n, 0 + BLOCK_SIZE*cnt)
            elif m[cnt][n] == 2:
                draw_point(25 + BLOCK_SIZE*n, 25 + BLOCK_SIZE*cnt)


class Actor(object):
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.dx = 0
        self.dy = 0
        self.px = 0
        self.py = 1      

    def update_direction(self):
        r = random.randint(0, 50)
        if r == 0:
            r2 = random.randint(0, 3)
            if r2 == 0:
                self.px = -1
                self.py = 0
            if r2 == 1:
                self.px = 1
                self.py = 0
            if r2 == 2:
                self.px = 0
                self.py = -1
            if r2 == 3:
                self.px = 0
                self.py = 1

    def make_step(self):
        if move_check_full(self.x + self.px, self.y + self.py):
            self.dx = self.px
            self.dy = self.py
        if move_check_full(self.x + self.dx, self.y + self.dy):
            self.x += self.dx
            self.y += self.dy

monsters = [
    Actor(382, 433),
    Actor(637, 533),
    Actor(688, 633),
    ]

player = Actor(76, 925)

running = True
button_left_hold = False
button_right_hold = False
button_up_hold = False
button_down_hold = False

dot_sound = mixer.Sound('mario-coin.wav')

#main loop
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            button_left_hold = False
            button_right_hold = False
            button_up_hold = False
            button_down_hold = False
            if event.key == pygame.K_LEFT:
                button_left_hold = True
            if event.key == pygame.K_RIGHT:
                button_right_hold = True
            if event.key == pygame.K_UP:
                button_up_hold = True
            if event.key == pygame.K_DOWN:
                button_down_hold = True
    #player
    if button_left_hold:
        player.px = -1
        player.py = 0
    if button_right_hold:
        player.px = 1
        player.py = 0
    if button_up_hold:
        player.px = 0
        player.py = -1
    if button_down_hold:
        player.px = 0
        player.py = 1
        
    player.make_step()
   
    if move_check(player.x, player.y) == 2 and count >= 0:
        #dot_sound = mixer.Sound('mario-coin.wav')
        if count_3 % 1 == 0:
            dot_sound.play()
        m[player.y // BLOCK_SIZE][player.x // BLOCK_SIZE] = 0
        count_2 -= 1
        count_3 += 1
        
    if count_2 == 0:
        print("VICTORY!!!!")
        mixer.music.load('john-cena.wav')
        mixer.music.play()
        time.sleep(4)
        running = False
        
    # monster
    for monster in monsters:
        monster.update_direction()
        monster.make_step()
    
    # check if monster bites
    for monster in monsters:
        if math.sqrt((player.x - monster.x)*(player.x - monster.x) + (monster.y - player.y)*(monster.y - player.y)) <= BLOCK_SIZE or\
           math.sqrt((player.x - monster.x)*(player.x - monster.x) + (monster.y - player.y)*(monster.y - player.y)) <= BLOCK_SIZE or\
           math.sqrt((player.x - monster.x)*(player.x - monster.x) + (monster.y - player.y)*(monster.y - player.y)) <= BLOCK_SIZE:
            mixer.music.load('lalstvo.wav')
            mixer.music.play()
            time.sleep(5)
            running = False
    
    screen.fill((BACKGROUND_COLOR))    

    draw_field()

    count += 1

    #draws player
    if (count//50) % 3 == 0:
        draw_player(player.x, player.y)
        draw_eye(player.x, player.y)
    elif (count//50) % 3 == 1:
        draw_player_1(player.x, player.y)
        draw_eye(player.x, player.y)
    else:
        draw_player_2(player.x, player.y)
        draw_eye(player.x, player.y)

###############=====================================================================########################
    if player.dx == -1 and player.dy == 0:
        if (count//50) % 3 == 0:
            draw_player(player.x, player.y)
            draw_eye(player.x - 14, player.y)
        elif (count//50) % 3 == 1:
            draw_mouth_1(player.x, player.y)
            draw_eye(player.x - 14, player.y)
        else:
            draw_mouth_2(player.x, player.y)
            draw_eye(player.x - 14, player.y)

    if player.dx == 1 and player.dy == 0:
        if (count//50) % 3 == 0:
            draw_player(player.x, player.y)
            draw_eye(player.x, player.y)
        elif (count//50) % 3 == 1:
            draw_player_1(player.x, player.y)
            draw_eye(player.x, player.y)
        else:
            draw_player_2(player.x, player.y)
            draw_eye(player.x, player.y)

    elif player.dx == 0 and player.dy == -1:
        if (count//50) % 3 == 0:
            draw_player(player.x, player.y)
            draw_eye(player.x + 10, player.y + 10)
        elif (count//50) % 3 == 1:
            draw_mouth_3(player.x, player.y)
            draw_eye(player.x + 10, player.y + 10)
        else:
            draw_mouth_4(player.x, player.y)
            draw_eye(player.x + 10, player.y + 10)

    elif player.dx == 0 and player.dy == 1:
        if (count//50) % 3 == 0:
            draw_player(player.x, player.y)
            draw_eye(player.x - 20, player.y + 15)
        elif (count//50) % 3 == 1:
            draw_mouth_5(player.x, player.y)
            draw_eye(player.x - 20, player.y + 15)
        else:
            draw_mouth_6(player.x, player.y)
            draw_eye(player.x - 20, player.y + 15)
            
    for monster in monsters:
        draw_monster(monster)

    pygame.display.flip()

pygame.quit()
